Ionita Radu-Alexandru 332CA
Nu am inteles foarte bine la ce trebuia facut poze, dar am facut la tot sa fiu sigur :)).
Am urmarit instructiunile exact ca in laborator.